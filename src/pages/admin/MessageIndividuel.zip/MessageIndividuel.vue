/* eslint-disable @typescript-eslint/no-unsafe-assignment */ /* eslint-disable
@typescript-eslint/no-unsafe-assignment */
<template>
  <q-page class="q-pa-lg">
    <q-card>
      <q-card-section>
        <div class="text-h4">CAMPAGNE SIMPLIFIEE</div>
        <div class="text-caption">Envoyer rapidement un message</div>
      </q-card-section>
      <q-separator></q-separator>
      <q-card-section class="q-pa-md">
        <div
          class="border-radius-inherit"
          :style="{ border: 'solid grey 1px' }"
        >
          <div class="row bg-grey-9 q-py-md q-px-xs text-grey-4">
            <div class="col-md-3">Credit Restant : 45</div>
            <div class="col-md-3">Credits A utiliser : 0</div>
            <div class="col-md-3">
              Nombre Destinataires:
              {{ destinataire === '' ? 0 : destinataire.split(';').length }}
            </div>
            <div class="col-md-3">Date Courante: 23 Mar 2022 12:03</div>
          </div>
          <div class="q-py-md q-px-lg">
            <q-form @submit="onSubmit">
              <div class="q-pb-md">
                <q-input
                  type="textarea"
                  autofocus
                  label="Numero Destinataire"
                  v-model="destinataire"
                  filled
                  no-error-icon
                  hint="Ajoutez plusieurs Numeros en les separant par des points virgule (;)"
                  stack-label
                  :rules="[(val) => !!val || 'Entrer au moins un numero']"
                />
              </div>
              <div class="row q-col-gutter-md">
                <div class="col-md-6">
                  <div class="q-pb-md">
                    <q-input
                      stack-label
                      filled
                      v-model="senderId"
                      no-error-icon
                      label="Nom de l'expéditeur"
                      placeholder="EX: STE GESSIIA"
                      :rules="[
                        (val) => !!val || 'Entrer le nom de l\'expediteur',
                      ]"
                    >
                    </q-input>
                  </div>
                  <div>
                    <q-input
                      type="textarea"
                      v-model="sms"
                      label="Message"
                      hint="1 Message(s) pour 4 Caractere(s)"
                      no-error-icon
                      placeholder="EX: Bonjour"
                      filled
                      stack-label
                      :rules="[
                        (val) => !!val || 'Entrer au moins un caractere',
                      ]"
                    />
                  </div>
                  <div class="row text-center q-col-gutter-md q-pt-md">
                    <div class="col-md-6">
                      <q-btn
                        label="Envoyez le message"
                        type="submit"
                        color="green"
                        no-caps
                      ></q-btn>
                    </div>
                    <div class="col-md-6">
                      <q-btn
                        label="effacer"
                        :style="{ width: 150 + 'px' }"
                        type="reset"
                        color="red"
                        no-caps
                      ></q-btn>
                    </div>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="q-pb-md">
                    <q-select
                      v-model="pays"
                      filled
                      :rules="[
                        (val) =>
                          val !== 'Aucun' || 'Veuillez selectionner un pays',
                      ]"
                      :loading="loadingPays"
                      :options="optionsPays"
                      label="Pays"
                    />
                  </div>
                  <div class="q-pb-md">
                    <q-input
                      type="textarea"
                      readonly
                      label="Visualiser le Message"
                      hint="1 Message(s) pour 4 Caractere(s)"
                      placeholder="EX: Bonjour"
                      filled
                      stack-label
                    />
                  </div>
                  <div class="row q-pt-md">
                    <div class="col-md-6">
                      <q-checkbox
                        label="Programmer le Message"
                        v-model="statusAuto"
                      />
                    </div>
                    <div class="col-md-6">
                      <q-input filled v-model="date" v-if="statusAuto">
                        <template v-slot:prepend>
                          <q-icon name="event" class="cursor-pointer">
                            <q-popup-proxy
                              cover
                              transition-show="scale"
                              transition-hide="scale"
                            >
                              <q-date v-model="date" mask="YYYY-MM-DD HH:mm">
                                <div class="row items-center justify-end">
                                  <q-btn
                                    v-close-popup
                                    label="Close"
                                    color="primary"
                                    flat
                                  />
                                </div>
                              </q-date>
                            </q-popup-proxy>
                          </q-icon>
                        </template>

                        <template v-slot:append>
                          <q-icon name="access_time" class="cursor-pointer">
                            <q-popup-proxy
                              cover
                              transition-show="scale"
                              transition-hide="scale"
                            >
                              <q-time
                                v-model="date"
                                mask="YYYY-MM-DD HH:mm"
                                format24h
                              >
                                <div class="row items-center justify-end">
                                  <q-btn
                                    v-close-popup
                                    label="Close"
                                    color="primary"
                                    flat
                                  />
                                </div>
                              </q-time>
                            </q-popup-proxy>
                          </q-icon>
                        </template>
                      </q-input>
                    </div>
                  </div>
                </div>
              </div>
            </q-form>
          </div>
        </div>
      </q-card-section>
    </q-card>
  </q-page>
</template>

<script lang="ts">
import { defineComponent, ref, onMounted } from 'vue';
import { api } from 'boot/axios';
import { useQuasar } from 'quasar';

import { Cookies } from 'quasar';

export default defineComponent({
  name: 'MessageIndividuel',
  setup() {
    onMounted(async () => {
      await getPays();
    });

    const search = ref('');
    const $q = useQuasar();
    const loadingPays = ref(false);

    const destinataire = ref('');
    const pays = ref({ id: 0, label: 'Aucun', routes: [{ id: 0 }] });
    const senderId = ref('');
    const clientId = ref(parseInt(Cookies.get('id')));
    const sms = ref('');
    const optionsPays = ref([{ id: 0, label: 'Aucun' }]);
    //const route = ref('');
    const statusAuto = ref(false);

    const getPaysAction = async (requestType: number) => {
      // eslint-disable-next-line @typescript-eslint/no-unused-vars,@typescript-eslint/no-explicit-any
      let dataRes: { status: boolean; data: [] } = { status: true, data: [] };
      if (requestType === 1) {
        await api
          .get('/api/pays')
          .then((response) => {
            dataRes = {
              status: true,
              data: <[]>response.data['hydra:member'],
            };
          })
          .catch(() => {
            dataRes = {
              status: false,
              data: [],
            };
          });
        return dataRes;
      }
    };

    const getPays = async () => {
      loadingPays.value = true;
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const response: any = await getPaysAction(1);
      console.log(response.data);
      if (response.status) {
        // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment,@typescript-eslint/no-unsafe-call,@typescript-eslint/no-explicit-any
        optionsPays.value = response.data.map((x: any) => {
          return {
            // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
            id: x['@id'],
            // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
            routes: x.routes,
            // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
            label: x.nom,
          };
        });
      } else {
        $q.notify({
          message: 'Erreur lors du chargement des pays',
          type: 'neagative',
        });
      }
      loadingPays.value = false;
    };

    const createSenderIdAction = async (senderId: string) => {
      let dataRes: { status: boolean; data: [] } = { status: true, data: [] };

      let dataSenderId = {
        // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
        senderId: senderId,
        description: 'string',
        status: true,
        clientId: clientId.value,
      };

      await api
        .post('/api/sender_ids', dataSenderId)
        .then((response1) => {
          // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access
          dataRes = {
            status: true,
            // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access
            data: <[]>response1.data,
          };
          console.log('xxxxxxxxxxx cas................', response1.data);
        })
        .catch(() => {
          dataRes = {
            status: false,
            data: [],
          };
        });

      // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access
      return dataRes;
    };
    const findSenderIdAction = async (
      requestType: number,
      senderId: string
    ) => {
      let dataRes: { status: boolean; data: [] } = { status: true, data: [] };
      if (requestType === 1) {
        await api
          .get('/api/sender_ids?senderId='.concat(senderId))
          .then(async (response) => {
            if (response.data['hydra:member'].length == 0) {
              var rep = await createSenderIdAction(senderId);
              // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access
              dataRes = {
                status: rep['status'], // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access
                data: rep['data'],
              };
              console.log('premier cas................', dataRes);
            } else {
              // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access
              dataRes = {
                status: true,
                // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access
                data: <[]>response.data['hydra:member'],
              };
              console.log('second cas................');
            }
          })
          .catch(() => {
            dataRes = {
              status: false,
              data: [],
            };
          });
        return dataRes;
      }
    };

    const createContactAction = async (
      requestType: number,
      contact: Array<string>,
      clientId: number
    ) => {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      let dataRes: { status: boolean; data: any[] } = {
        status: true,
        data: [],
      };
      if (requestType === 1) {
        for (let i = 0; i < contact.length; i++) {
          let data = {
            phone: contact[i],
            clientId: clientId,
          };
          await api
            .post('/api/contacts', data)
            .then((response) => {
              dataRes.status = true;
              // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access
              dataRes.data.push(response.data['@id']);
            })
            .catch(() => {
              dataRes.status = false;
            });
        }
      }
      console.log('coiiiiiiiiiii', dataRes);
      return dataRes;
    };

    const findContactAction = async (
      requestType: number,
      contact: Array<string>,
      clientId: number
    ) => {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      let dataRes: { status: boolean; data: any[] } = {
        status: true,
        data: [],
      };
      if (requestType === 1) {
        for (let i = 0; i < contact.length; i++) {
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          let res1: any[] = [];
          await api
            .get(
              '/api/contacts?phone='
                .concat(contact[i])
                .concat('&clientId=')
                .concat(clientId.toString())
            )
            .then((response) => {
              // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access,@typescript-eslint/no-unsafe-assignment
              res1 = response.data['hydra:member'];
              dataRes.status = true;
            })
            .catch(() => {
              dataRes.status = false;
            });
          if (dataRes.status) {
            // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access
            if (res1.length === 0) {
              // eslint-disable-next-line @typescript-eslint/no-explicit-any
              let tempDataRes: { status: boolean; data: any[] } =
                await createContactAction(1, [contact[i]], clientId);
              if (tempDataRes.status) {
                // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
                dataRes.data.push({ contact: tempDataRes.data[0] });
              } else {
                dataRes.status = false;
              }
            } else {
              dataRes.status = true;
              // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access,@typescript-eslint/no-unsafe-assignment
              dataRes.data.push({ contact: res1[0]['@id'] });
            }
          }
        }
      }
      return dataRes;
    };

    const createSmsAction = async (requestType: number, datas: object) => {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      let dataRes: { status: boolean; data: any[] } = {
        status: true,
        data: [],
      };
      // eslint-disable-next-line @typescript-eslint/no-unsafe-call
      if (requestType === 1) {
        await api
          .post('/api/sms', datas)
          .then((response) => {
            dataRes = {
              status: true,
              // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access
              data: [response.data['@id']],
            };
          })
          .catch(() => {
            dataRes = {
              status: false,
              data: [],
            };
          });
        //await createSmsByRouteAction(1, senderId.value);
      }
      return dataRes;
    };

    /*const createSmsByRouteAction = async (
        routeId: number,
        senderId: string
      ) => {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        let dataRes: { status: boolean; data: any[] } = {
          status: true,
          data: [],
        };
        // eslint-disable-next-line @typescript-eslint/no-unsafe-call
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        let responseGetroute: any = await api
          .get('/api/sender_apis?id='.concat(routeId.toString()))
          .then((response) => {
            // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access
            // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access
            route.value = response.data['hydra:member'][0]['api_Link'] as string;
            // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access
            console.log('senderpi..........', route.value);

            return {
              status: true,
              // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access
              data: [response.data['@id']],
            };
          })
          .catch(() => {
            return {
              status: false,
              data: [],
            };
          });

        // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access
        if (responseGetroute.status) {
          var toRoute = {
            senderId: senderId,
            message: sms.value,
            destinataire: destinataire.value.split(','),
          };
          console.log('voici pour la route', route.value, toRoute);
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          let responseSendSms: any = await api
            .post(route.value, toRoute)
            .then((response) => {
              return {
                status: true,
                // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access
                data: [response.data['@id']],
              };
            })
            .catch(() => {
              return {
                status: false,
                data: [],
              };
            });
          // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access
          if (responseSendSms.status) {
            $q.notify({
              message: 'Message envoyer avec success.',
              type: 'positive',
            });
          } else {
            $q.notify({
              message: 'Une erreur est survenue veuillez reessayer.',
              type: 'negative',
            });
          }
        } else {
          $q.notify({
            message: 'Une erreur est survenue veuillez reessayer.',
            type: 'negative',
          });
        }
        return dataRes;
      };*/

    const createLotAction = async (requestType: number, datas: object) => {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      let dataRes: { status: boolean; data: any[] } = {
        status: true,
        data: [],
      };
      // eslint-disable-next-line @typescript-eslint/no-unsafe-call
      if (requestType === 1) {
        await api
          .post('/api/lots', datas)
          .then((response) => {
            // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access
            dataRes = {
              status: true,
              // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access
              data: [response.data['@id']],
            };
          })
          .catch(() => {
            dataRes = {
              status: false,
              data: [],
            };
          });
      }
      return dataRes;
    };

    const onSubmit = async () => {
      let datas1 = {
        requestType: 1,
        senderId: senderId.value,
      };

      if (pays.value.id === 0) {
        $q.notify({
          message: 'Le pays est requis',
          type: 'info',
        });
        return 0;
      }

      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const response1: any = await findSenderIdAction(
        datas1.requestType,
        datas1.senderId
      );
      // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access
      if (response1.status) {
        // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access

        // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access
        if (response1.data.length !== 0) {
          // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access,@typescript-eslint/no-unsafe-assignment

          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          let response2: any = await findContactAction(
            1,
            destinataire.value.indexOf(';') !== -1
              ? destinataire.value.split(';')
              : [destinataire.value],
            clientId.value
          );
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          let response3: any = await createLotAction(1, {});
          // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access
          console.log(response2.status, response3.status);
          console.log(pays.value);
          if (response2.status && response3.status) {
            let dataSms = {
              message: sms.value,
              status: true,
              clientId: clientId.value,
              // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
              senderId: response1.data[0]['@id'],
              listSmsLotsEnvoyes: [
                {
                  status: true,
                  // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment,@typescript-eslint/no-unsafe-member-access
                  listSmsContacts: response2.data,
                  // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access,@typescript-eslint/no-unsafe-assignment
                  lot: response3.data[0],
                  routeListSmsLotsEnvoyes: [
                    {
                      // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
                      routeId: pays.value.routes[0].id,
                    },
                  ],
                },
              ],
            };
            console.log(dataSms);
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            let response4: any = await createSmsAction(1, dataSms);
            // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access
            if (response4.status) {
              $q.notify({
                message: 'Message envoyer avec success.',
                type: 'positive',
              });
            } else {
              $q.notify({
                message: "Une erreur est survenu lors de l'operation.",
                type: 'neagative',
              });
            }
          } else {
            $q.notify({
              message: "Une erreur est survenu lors de l'operation.",
              type: 'negative',
            });
          }
        } else {
          $q.notify({
            message: 'Aucun expediteur pour ce nom : '.concat(senderId.value),
            type: 'warning',
          });
        }
      } else {
        $q.notify({
          message: "Une erreur est survenu lors de l'operation.",
          type: 'negative',
        });
      }
    };

    return {
      optionsPays,
      search,
      sms,
      getPays,
      senderId,
      destinataire,
      statusAuto,
      createLotAction,
      pays,
      loadingPays,
      onSubmit,
      date: ref('2019-02-01 12:44'),
    };
  },
});
</script>
